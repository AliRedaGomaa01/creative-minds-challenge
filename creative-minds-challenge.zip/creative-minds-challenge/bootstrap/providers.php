<?php

return [
    App\Providers\AppServiceProvider::class,
    Kreait\Laravel\Firebase\ServiceProvider::class,
    App\Providers\TelescopeServiceProvider::class,
];
